#############################################################
##                 E X T R A C T E D    B Y                ## L I C E N C E
############################################################# Personal use
##             _                          _ _              ##
##  _ __   ___ | |_   _  __ _   ___  _ __ | (_)_ __   ___  ## C R E D I T
## | '_ \ / _ \| | | | |/ _` | / _ \| '_ \| | | '_ \ / _ \ ## Extracted by Finneh on
## | |_) | (_) | | |_| | (_| || (_) | | | | | | | | |  __/ ## the City Loopers Discord.
## | .__/ \___/|_|\__, |\__, (_)___/|_| |_|_|_|_| |_|\___| ## 
## |_|            |___/ |___/                              ## Font made by PTV
#############################################################

THIS FONT HAS BEEN EXTRACTED FROM THE PUBLIC TRANSPORT VICTORIA WEBSITE, AND IS THEIR PROPERTY.
COMMERCIAL USE IS NOT PERMITTED WITHOUT PERMISSION FROM PTV OR RELATED ENTITIES.

I DO NOT OWN THIS FONT. FOR REMOVAL, PLEASE EMAIL * hello@polyg.online *