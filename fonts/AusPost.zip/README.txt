###################################################################  #############################################################
##     _    ____    _______   ______  _____   ____  ____   ___   ##  ##             _                          _ _              ##
##    / \  |  _ \  |_   _\ \ / /  _ \| ____| |  _ \|  _ \ / _ \  ##  ##  _ __   ___ | |_   _  __ _   ___  _ __ | (_)_ __   ___  ##
##   / _ \ | |_) |   | |  \ V /| |_) |  _|   | |_) | |_) | | | | ##  ## | '_ \ / _ \| | | | |/ _` | / _ \| '_ \| | | '_ \ / _ \ ##
##  / ___ \|  __/    | |   | | |  __/| |___  |  __/|  _ <| |_| | ##  ## | |_) | (_) | | |_| | (_| || (_) | | | | | | | | |  __/ ##
## /_/   \_\_|       |_|   |_| |_|   |_____| |_|   |_| \_\\___/  ##  ## | .__/ \___/|_|\__, |\__, (_)___/|_| |_|_|_|_| |_|\___| ##
##                                                               ##  ## |_|            |___/ |___/                              ##
###################################################################  #############################################################

This font was extracted by Polygon (polyg.online).

THIS FONT HAS BEEN EXTRACTED FROM THE AUSTRALIA POST WEBSITE, AND IS PROPERTY OF AUSTRALIA POST.
COMMERCIAL USE IS NOT PERMITTED WITHOUT PERMISSION FROM AUSTRALIA POST AND RELATED ENTITIES. FOR
PERSONAL/NON COMMERCIAL USE ONLY. 

WE DO NOT OWN THIS FONT. FOR REMOVAL, PLEASE EMAIL * hello@polyg.online *