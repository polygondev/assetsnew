#############################################################
##                 E X T R A C T E D    B Y                ## L I C E N C E
############################################################# Personal use
##             _                          _ _              ##
##  _ __   ___ | |_   _  __ _   ___  _ __ | (_)_ __   ___  ## C R E D I T
## | '_ \ / _ \| | | | |/ _` | / _ \| '_ \| | | '_ \ / _ \ ## Australian Broadcasting
## | |_) | (_) | | |_| | (_| || (_) | | | | | | | | |  __/ ## Corporation
## | .__/ \___/|_|\__, |\__, (_)___/|_| |_|_|_|_| |_|\___| ## 
## |_|            |___/ |___/                              ## 
#############################################################

THIS FONT HAS BEEN EXTRACTED FROM THE ABC WEBSITE, AND IS THEIR PROPERTY.
COMMERCIAL USE IS NOT PERMITTED WITHOUT PERMISSION FROM ABC OR RELATED ENTITIES.

I DO NOT OWN THIS FONT. FOR REMOVAL, PLEASE EMAIL * hello@polyg.online *
